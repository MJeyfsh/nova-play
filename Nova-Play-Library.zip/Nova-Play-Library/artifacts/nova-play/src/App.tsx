import { type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowRight, Search, X, Info, SlidersHorizontal } from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All games');
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const games = useMemo<Game[]>(() => [
    {
      id: 'gta-v', title: 'GTA V', art: 'gta', wordmark: 'GRAND THEFT<br />AUTO V',
      genre: ['Action', 'Adventure'], description: 'A sprawling open-world crime saga set across the sunlit streets and backroads of Los Santos. Switch between three distinct lives as their stories collide in a city built for chaos.',
      cardGenre: 'OPEN-WORLD ACTION',
    },
    {
      id: 'call-of-duty', title: 'Call of Duty', art: 'duty', wordmark: 'CALL OF<br />DUTY',
      genre: ['Shooter', 'Action'], description: 'A high-intensity military shooter series built around cinematic campaigns and competitive combat. This listing represents the Call of Duty franchise, not one specific installment.',
      cardGenre: 'MILITARY SHOOTER',
    },
    {
      id: 'days-gone', title: 'Days Gone', art: 'days', wordmark: 'DAYS<br />GONE',
      genre: ['Action', 'Survival'], description: 'Ride a battered motorcycle through a dangerous, overgrown Pacific Northwest. Scavenge, adapt, and navigate a harsh world where every trip beyond camp carries a risk.',
      cardGenre: 'SURVIVAL ACTION',
    },
    {
      id: 'scum', title: 'SCUM', art: 'scum', wordmark: 'SCUM',
      genre: ['Survival'], description: 'A detailed multiplayer survival experience on a sprawling island. Manage resources, endure the elements, and make hard choices in a world where survival is the objective.',
      cardGenre: 'OPEN-WORLD SURVIVAL',
    },
  ], []);
  const categories = ['All games', 'Action', 'Shooter', 'Survival'];
  const visibleGames = useMemo(() => {
    const query = search.trim().toLowerCase();
    return games.filter((game) => {
      const matchesCategory = category === 'All games' || game.genre.includes(category);
      const matchesSearch = !query || [game.title, game.cardGenre, ...game.genre, game.description].join(' ').toLowerCase().includes(query);
      return matchesCategory && matchesSearch;
    });
  }, [category, games, search]);

  useEffect(() => {
    if (!selectedGame) return;
    closeButtonRef.current?.focus();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSelectedGame(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selectedGame]);

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand" aria-label="Nova Play home" data-testid="brand-nova-play">
          <span className="brand-mark" aria-hidden="true" />
          <span>NOVA PLAY</span>
        </div>
        <div className="top-status" data-testid="status-catalogue-only">
          <span className="status-dot" aria-hidden="true" />
          Catalogue preview
        </div>
      </header>

      <section className="hero" aria-labelledby="hero-title">
        <div className="eyebrow">Your next world is waiting</div>
        <h1 id="hero-title">Find your<br /><span>next obsession.</span></h1>
        <p className="hero-copy">A handpicked catalogue of worlds worth getting lost in. Explore the games, find your genre, and see what calls you in.</p>
      </section>

      <section className="catalog" aria-labelledby="catalog-title">
        <div className="catalog-head">
          <div>
            <h2 className="section-title" id="catalog-title">The catalogue</h2>
            <p className="section-sub">Four worlds. A thousand ways to disappear.</p>
          </div>
          <label className="search-wrap">
            <Search size={17} aria-hidden="true" />
            <span className="sr-only">Search games</span>
            <input
              className="search-input"
              type="search"
              placeholder="Search titles or genres"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              data-testid="input-game-search"
            />
          </label>
        </div>

        <div className="filter-row" aria-label="Filter games by category" data-testid="filters-category">
          <SlidersHorizontal size={15} aria-hidden="true" style={{ color: '#827b8d', alignSelf: 'center', marginRight: 3 }} />
          {categories.map((item) => (
            <button
              key={item}
              type="button"
              className="filter-chip"
              aria-pressed={category === item}
              onClick={() => setCategory(item)}
              data-testid={`filter-${item.toLowerCase().replaceAll(' ', '-')}`}
            >
              {item}
            </button>
          ))}
          <span className="results-line" data-testid="text-results-count">{visibleGames.length} / 4 titles</span>
        </div>

        {visibleGames.length > 0 ? (
          <div className="game-grid" data-testid="grid-game-catalogue">
            {visibleGames.map((game, index) => (
              <article className="game-card" key={game.id} data-testid={`card-game-${game.id}`}>
                <div className={`art art-${game.art}`} role="img" aria-label={`${game.title} atmospheric artwork`}>
                  <div className="art-lines" aria-hidden="true" />
                  <span className="art-index">0{index + 1} / 04</span>
                  <span className="art-word" dangerouslySetInnerHTML={{ __html: game.wordmark }} />
                </div>
                <div className="card-body">
                  <div className="card-meta">
                    <span className="genre">{game.cardGenre}</span>
                    <span className="listing-tag">Catalogue only</span>
                  </div>
                  <h3 data-testid={`text-game-title-${game.id}`}>{game.title}</h3>
                  <div className="card-actions">
                    <span className="card-note">Details, not launch</span>
                    <button className="details-btn" type="button" onClick={() => setSelectedGame(game)} aria-label={`View details for ${game.title}`} data-testid={`button-details-${game.id}`}>
                      Details <span aria-hidden="true"><ArrowRight size={13} /></span>
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="empty-state" role="status" data-testid="empty-no-games">
            <div className="empty-icon"><Search size={19} aria-hidden="true" /></div>
            <h3>No worlds found</h3>
            <p>Try another title or clear your filters to see the full catalogue.</p>
            <button className="reset-btn" type="button" onClick={() => { setSearch(''); setCategory('All games'); }} data-testid="button-reset-filters">Clear search & filters</button>
          </div>
        )}
      </section>

      <aside className="availability" aria-label="Catalogue availability notice" data-testid="notice-no-streaming">
        <Info className="availability-icon" size={17} aria-hidden="true" />
        <div>
          <strong>Browse only. No streaming or launching.</strong>
          <p>These are catalogue listings for discovery. Games cannot be played here; a legitimate cloud-gaming server would need to be connected before any streaming is available.</p>
        </div>
      </aside>

      <footer className="footer">
        <span>NOVA PLAY <span style={{ color: '#494351' }}>—</span> Game discovery, reimagined</span>
        <span>Independent catalogue prototype</span>
      </footer>

      {selectedGame && (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelectedGame(null); }} data-testid="modal-game-details">
          <section className="detail-modal" role="dialog" aria-modal="true" aria-labelledby="modal-game-title">
            <div className={`modal-art art-${selectedGame.art}`} aria-hidden="true">
              <div className="art-lines" />
              <span className="art-word" dangerouslySetInnerHTML={{ __html: selectedGame.wordmark }} />
            </div>
            <div className="modal-content">
              <div className="modal-top">
                <span className="genre">{selectedGame.genre.join(' / ').toUpperCase()}</span>
                <button ref={closeButtonRef} className="modal-close" type="button" aria-label="Close game details" onClick={() => setSelectedGame(null)} data-testid="button-close-details"><X size={17} /></button>
              </div>
              <h2 id="modal-game-title" data-testid="text-modal-game-title">{selectedGame.title}</h2>
              <p data-testid="text-game-description">{selectedGame.description}</p>
              <div className="modal-rule" />
              <div className="modal-footnote"><Info size={15} aria-hidden="true" /><span>Catalogue listing only. This prototype does not launch or stream games.</span></div>
            </div>
          </section>
        </div>
      )}
    </main>
  );
}

type Game = {
  id: string;
  title: string;
  art: string;
  wordmark: string;
  genre: string[];
  description: string;
  cardGenre: string;
};

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
